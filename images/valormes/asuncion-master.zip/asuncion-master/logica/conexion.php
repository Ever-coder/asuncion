<?php

$host = "localhost";
$user = "root";
$clave = "";
$bd  = "administ_solicitud_de_informacion";

$conectar = mysqli_connect($host,$user,$clave,$bd);




?>